#!/usr/bin/env bash
# Builds the Google Play release bundle (.aab).
#   1. web build for the store (real multiplayer server, QA ?devshop unlock removed, store packs included)
#   2. npx cap sync android
#   3. ./gradlew bundleRelease
# Signing: android/keystore.properties (gitignored, see android/keystore.properties.example). Without it the AAB is
# UNSIGNED — good for checking that the build works, but Play Console needs it signed with your upload key.
# Version: android/variables.gradle (appVersionCode / appVersionName) — bump appVersionCode before every upload.
# Usage: npm run android:release        (env overrides: VITE_SERVER_URL, VITE_ALL_STORE_PACKS=0 to keep packs locked)
set -euo pipefail
cd "$(dirname "$0")/.."

export VITE_SERVER_URL="${VITE_SERVER_URL:-wss://fucustomer-game.typeu910722.workers.dev/ws}"
export VITE_NO_DEVSHOP=1
# Free Play release without Google Play Billing: the 10 pack stores are included for everyone (0 = keep them locked).
if [ "${VITE_ALL_STORE_PACKS:-1}" = "0" ]; then export VITE_ALL_STORE_PACKS=; else export VITE_ALL_STORE_PACKS=1; fi

echo "== web build → dist/ (server $VITE_SERVER_URL, store packs included: ${VITE_ALL_STORE_PACKS:-no})"
npx vite build
echo "== cap sync android"
npx cap sync android
echo "== gradle bundleRelease"
(cd android && ./gradlew bundleRelease --max-workers="${GRADLE_WORKERS:-2}")

AAB=android/app/build/outputs/bundle/release/app-release.aab
VER=$(grep -E "appVersion(Code|Name)" android/variables.gradle | sed -E 's/.*= *//' | tr -d "'" | paste -sd' ')
if [ -f android/keystore.properties ]; then SIGNED="signed with your upload key"; else SIGNED="UNSIGNED (no android/keystore.properties) — Play Console will reject it"; fi
echo
echo "AAB: $(pwd)/$AAB"
echo "     $(du -h "$AAB" | cut -f1), versionCode/versionName: $VER, $SIGNED"
