// Google Play screenshots (16:9 landscape) from the real game in headless Chromium with touch emulation, so the
// on-screen controls (joystick, action buttons) show exactly as on a phone/tablet. Software WebGL, quality "high".
// Needs the Play build served somewhere (single-player runs fully in the page, no game server needed), e.g.
//   VITE_NO_DEVSHOP=1 VITE_ALL_STORE_PACKS=1 npx vite build && npx vite preview --port 4319
// Usage: GAME_URL=http://127.0.0.1:4319/ node store/src/play-screens.mjs   → store/google-play/{phone,tablet-7,tablet-10}/
//        DEVICES=phone ONLY=01,05 … to retake some of them.
// Play Console rules (以官方為準): 24-bit PNG/JPEG without alpha; phone: each side 320–3840 px, long side ≤ 2× short side;
// tablets: 1080–7680 px, 16:9 landscape. Games: at least three 16:9 landscape shots of at least 1920×1080 recommended.
// The shots use the same debug hooks as the e2e tests (window.__game, the local Room) to place the camera and freeze
// the moment; grabbing, throwing and talking use the real on-screen touch buttons.
import { createRequire } from 'node:module';
import path from 'node:path';
import { mkdirSync } from 'node:fs';
const require = createRequire(import.meta.url);
let pw; try { pw = require('playwright'); } catch { pw = require('/opt/node-tools/node_modules/playwright'); }
const GAME = process.env.GAME_URL ?? 'http://127.0.0.1:4319/';
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../google-play');
const ONLY = process.env.ONLY ? process.env.ONLY.split(',') : null;
const want = name => !ONLY || ONLY.some(o => name.startsWith(o));
// CSS viewport × scale = output pixels. Phone: a 960×540 CSS screen (typical landscape phone UI size).
const DEVICES = {
  phone: { viewport: { width: 960, height: 540 }, scale: 2 },          // 1920×1080
  'tablet-7': { viewport: { width: 1024, height: 576 }, scale: 1.875 }, // 1920×1080
  'tablet-10': { viewport: { width: 1280, height: 720 }, scale: 2 },    // 2560×1440
};
const ONLY_DEV = process.env.DEVICES ? process.env.DEVICES.split(',') : Object.keys(DEVICES);
const browser = await pw.chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ALL_KARENS = ['cutter', 'rager', 'streamer', 'hog', 'litterer', 'charger', 'custom', 'fickle', 'tryhard', 'boss', 'sampler', 'reader', 'toucher', 'taster', 'dogfeed', 'squatter', 'kicker', 'packer', 'wiper', 'benchhog', 'doneness', 'refry', 'unboxer', 'photo', 'coins', 'rx', 'upgrader'];
const MAPS = ['convenience', 'bakery', 'boba', 'bookstore', 'breakfast', 'cafe', 'chicken', 'cinema', 'clothing', 'drugstore', 'electronics', 'gas', 'gym', 'hotel', 'hotpot', 'petshop', 'pharmacy', 'post', 'salon', 'steak', 'supermarket'];

let OUT = ROOT, DEV = DEVICES.phone;
/** A fresh touch-device profile: career level, stars and seen-karens set so no tutorial or intro cards get in the way. */
async function open(level, cleared, { extra = [], name = '阿明', profile = {}, seed = 7 } = {}) {
  const ctx = await browser.newContext({ viewport: DEV.viewport, deviceScaleFactor: DEV.scale, hasTouch: true, isMobile: true });
  await ctx.addInitScript(seed => { let a = seed >>> 0; Math.random = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }, seed);
  const page = await ctx.newPage();
  page.on('pageerror', e => console.error('page error', String(e)));
  await page.goto(GAME);
  const stars = {}, clears = {};
  for (let c = 1; c <= cleared; c++) for (let i = 1; i <= 5; i++) { stars[`${c}-${i}`] = 2 + ((c + i) % 2); clears[`${c}-${i}`] = 1; }
  for (const id of extra) { stars[id] = 2; clears[id] = 1; }
  await page.evaluate(([level, stars, clears, karens, maps, name, profile]) => {
    localStorage.clear();
    localStorage.setItem('fucustomer.settings.v1', JSON.stringify({ quality: 'high', name, fov: 80, fpsCap: 0, adaptive: false, volume: 0, music: 0 }));
    localStorage.setItem('fucustomer.flags.v1', JSON.stringify({ tutorialDone: true, seenKarens: karens, seenMaps: maps }));
    localStorage.setItem('fucustomer.career.v1', JSON.stringify({ version: 1, level, exp: 40, wallet: 1860, skillPoints: 2, skills: { service: 6, body: 7, crisis: 5 }, gear: { shoes: 2, mop: 2, machine: 1, cleaner: 1, guard: 1 }, stars, clears, stats: { shifts: 60, wins: 52, served: 1400, ejected: 120, karens: 180, revenue: 18000 }, endlessBest: 1240, title: '', achievements: ['FIRST_SHIFT', 'FIRST_THROW', 'CH1', 'CH2', 'CH3', 'LV10', 'LV20', 'KARENS_100', 'SERVED_1000', 'STARS_60', 'COMBO_5', 'DAILY_FIRST'], story: ['ch1-intro', 'ch2-intro', 'ch3-intro', 'ch4-intro', 'ch5-intro', 'ch6-intro', 'ch7-intro', 'ch8-intro', 'first-court'], ...profile }));
  }, [level, stars, clears, ALL_KARENS, MAPS, name, profile]);
  await page.reload();
  await page.addStyleTag({ content: '.ts-foot .muted { display: none !important; }' }); // server address line on the title screen
  return { ctx, page };
}
const shot = async (page, name, wait = 1500) => { await page.waitForTimeout(wait); await page.screenshot({ path: path.join(OUT, name), timeout: 180000 }); console.log('wrote', path.relative(ROOT, path.join(OUT, name))); };
const click = (page, sel) => page.locator(sel).first().click();
/** Presses an on-screen touch button (#t-grab, #t-interact…) the way a finger does: pointerdown, short hold, pointerup. */
const press = async (page, id) => {
  await page.evaluate(id => document.getElementById(id).dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerType: 'touch', pointerId: 77 })), id);
  await page.waitForTimeout(150);
  await page.evaluate(id => document.getElementById(id).dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'touch', pointerId: 77 })), id);
};

// ---- in-page helpers (solo: the whole simulation runs in the page) ----
const look = (page, x, z, yaw, pitch) => page.evaluate(([x, z, yaw, pitch]) => {
  const g = window.__game, me = g.conn.room.world.players.get(g.selfId);
  g.pos = { x, z }; g.yaw = yaw; g.pitch = pitch; me.x = x; me.z = z; me.yaw = yaw;
}, [x, z, yaw, pitch]);
const lookAt = (page, x, z, tx, tz, ty = 1.2) => look(page, x, z, Math.atan2(tx - x, tz - z), Math.atan2(ty - 1.62, Math.hypot(tx - x, tz - z)));
const freeze = page => page.evaluate(() => clearInterval(window.__game.conn.timer));
const step = (page, n) => page.evaluate(n => {
  const r = window.__game.conn.room;
  for (let i = 0; i < n; i++) r.update(0.05);
  for (const m of r.members.values()) r.sendSnapshotTo(m);
}, n);
const spawn = (page, id, kind, x, z, extra = {}) => page.evaluate(([id, kind, x, z, extra]) => {
  window.__game.conn.room.world.customers.push({ id, kind, x, z, yaw: Math.PI, state: 'complain', path: [], speed: 0, shopping: [], items: [], want: null, foodDone: false, foodFailed: false, patience: 100, patienceMax: 100, mood: 80, timer: 0, register: -1, anger: 60, resolved: false, hits: 0, eaten: [], eatShelf: null, life: 999, look: 3, angry: true, moving: false, knockTimer: 99, gone: false, heldBy: null, fly: null, phase: 0, minions: [], ...extra });
}, [id, kind, x, z, extra]);
const coworker = (page, id, name, color, x, z, yaw) => page.evaluate(([id, name, color, x, z, yaw]) => {
  const w = window.__game.conn.room.world, me = w.players.get(window.__game.selfId);
  w.players.set(id, { ...me, id, name, color, x, z, yaw, held: null, held2: null, grabbing: null, busy: null, recent: new Map(), stats: { served: 0, karens: 0, cleaned: 0, restocked: 0, ejected: 0 } });
}, [id, name, color, x, z, yaw]);
const clearArea = (page, x0, z0, x1, z1, keep = []) => page.evaluate(([x0, z0, x1, z1, keep]) => {
  const w = window.__game.conn.room.world;
  w.customers = w.customers.filter(c => keep.includes(c.id) || !(c.x > x0 && c.x < x1 && c.z > z0 && c.z < z1));
}, [x0, z0, x1, z1, keep]);
const clearLine = (page, px, pz, x, z, keep = []) => page.evaluate(([px, pz, x, z, keep]) => {
  const w = window.__game.conn.room.world;
  const L = Math.hypot(x - px, z - pz);
  w.customers = w.customers.filter(c => {
    if (keep.includes(c.id)) return true;
    const t = ((c.x - px) * (x - px) + (c.z - pz) * (z - pz)) / (L * L);
    const qx = px + (x - px) * t, qz = pz + (z - pz) * t;
    return !(t > -0.1 && t < 0.92 && Math.hypot(c.x - qx, c.z - qz) < 0.9) && Math.hypot(c.x - px, c.z - pz) > 1.3;
  });
}, [px, pz, x, z, keep]);
const tidy = page => page.evaluate(() => { const w = window.__game.conn.room.world; for (const k in w.shelves) w.shelves[k] = Math.max(w.shelves[k], 7); w.rating = Math.max(w.rating, 3.4); w.chaos = Math.min(w.chaos, 30); w.spills = w.spills.slice(0, 1); w.event = null; w.power = 1; w.nextEvent = 999; });
const callKarens = (page, kinds, max = 3) => page.evaluate(([kinds, max]) => {
  const w = window.__game.conn.room.world;
  w.cfg = { ...w.cfg, karens: kinds, maxKarens: max };
  w.karenTimer = 0;
}, [kinds, max]);
const runUntil = (page, kind, secs = 120, states = null) => page.evaluate(([kind, n, states]) => {
  const r = window.__game.conn.room;
  for (let i = 0; i < n; i++) {
    r.update(0.05);
    const c = r.world.customers.find(c => c.kind === kind && !c.gone && !c.fly && !c.heldBy && (!states || states.includes(c.state)));
    if (c) return { id: c.id, x: c.x, z: c.z, state: c.state };
  }
  return null;
}, [kind, secs * 20, states]);
const faceFrom = async (page, x, z, dist, { side = 0, ty = 1.2, cx = 12, cz = 8 } = {}) => {
  let dx = cx - x, dz = cz - z; const d = Math.hypot(dx, dz) || 1; dx /= d; dz /= d;
  const a = Math.atan2(dx, dz) + side;
  const px = Math.min(23, Math.max(1, x + Math.sin(a) * dist)), pz = Math.min(15.3, Math.max(1, z + Math.cos(a) * dist));
  await lookAt(page, px, pz, x, z, ty);
};

async function freePlay(page, id, secs) {
  await click(page, '#m-career'); await click(page, '[data-tab="free"]'); await page.waitForSelector('.mapcard');
  await click(page, `[data-map="${id}"]`);
  await page.waitForFunction(() => window.__game?.started && window.__game.snap, null, { timeout: 60000 });
  await page.evaluate(n => { const r = window.__game.conn.room; r.world.phaseLeft = 0.1; for (let i = 0; i < n; i++) r.update(0.05); }, secs * 20);
}
async function startShift(page, id, warm) {
  await click(page, '#m-career');
  await click(page, '[data-tab="chapters"]');
  await click(page, `[data-play="${id}"]`);
  await page.waitForFunction(() => document.querySelector('.scene') || window.__game?.started, null, { timeout: 60000 });
  for (let i = 0; i < 10 && await page.locator('.scene').count(); i++) { await page.keyboard.press('Enter'); await page.waitForTimeout(150); }
  await page.waitForFunction(() => window.__game?.started, null, { timeout: 60000 });
  if (await page.locator('#pb-ready').count()) await click(page, '#pb-ready'); else await page.keyboard.press('Enter');
  await page.waitForFunction(() => window.__game.snap.phase === 'open', null, { timeout: 60000 });
  await page.evaluate(n => { const r = window.__game.conn.room; r.paused = false; for (let i = 0; i < n; i++) r.update(0.05); }, warm);
}

for (const dev of ONLY_DEV) {
  DEV = DEVICES[dev]; OUT = path.join(ROOT, dev); mkdirSync(OUT, { recursive: true });
  // 01 — a karen thrown out the front door, mid-air
  if (want('01')) {
    const { ctx, page } = await open(18, 3);
    await freePlay(page, 'convenience', 40);
    await freeze(page);
    await clearArea(page, 3, 4, 21, 16.5);
    await spawn(page, 9001, 'rager', 12, 10.0, { anger: 85 });
    await look(page, 12, 9.0, 0, 0.0);
    await step(page, 2);
    await page.waitForTimeout(500);
    await press(page, 't-grab');
    await step(page, 2);
    // software rendering is slow: keep stepping the world until the frame loop has sent the grab and the room took it
    for (let i = 0; i < 60 && !(await page.evaluate(() => window.__game.conn.room.world.players.get(window.__game.selfId).grabbing === 9001)); i++) { await step(page, 1); await page.waitForTimeout(150); }
    await look(page, 12, 9.0, 0, 0.45);
    await page.waitForTimeout(800);
    await press(page, 't-grab');
    for (let i = 0; i < 60 && !(await page.evaluate(() => window.__game.conn.room.world.customers.find(c => c.id === 9001)?.fly)); i++) { await page.waitForTimeout(150); await step(page, 0); }
    if (!(await page.evaluate(() => window.__game.conn.room.world.customers.find(c => c.id === 9001)?.fly))) throw new Error('throw did not happen');
    for (let i = 0; i < 5; i++) { await step(page, 1); await page.waitForTimeout(150); }
    await coworker(page, 'pX', '阿傑', 0x48a6ff, 12, 9.0, 0);
    await lookAt(page, 14.2, 14.8, 11.6, 11.6, 1.4);
    await step(page, 0);
    await shot(page, '01-throw.png');
    await ctx.close();
  }
  // 02 — a busy supermarket seen from the till: a queue and karens
  if (want('02')) {
    const { ctx, page } = await open(18, 3);
    await freePlay(page, 'supermarket', 50);
    await freeze(page);
    await page.evaluate(() => { const w = window.__game.conn.room.world; w.cfg = { ...w.cfg, maxCustomers: 16, spawnEvery: 1.6 }; });
    for (let i = 0; i < 5; i++) {
      await callKarens(page, ['rager', 'cutter', 'streamer'], 3);
      await page.evaluate(() => { const w = window.__game.conn.room.world; for (const k in w.shelves) w.shelves[k] = 10; w.chaos = 25; w.rating = 3.6; w.spills = w.spills.slice(0, 1); });
      await step(page, 160);
    }
    await runUntil(page, 'rager', 60, ['complain']);
    await page.evaluate(() => { const w = window.__game.conn.room.world; for (const k in w.shelves) w.shelves[k] = 9; w.chaos = 30; w.spills = w.spills.slice(0, 1); });
    await lookAt(page, 17.9, 10.3, 16.0, 14.5, 1.05);
    await step(page, 1);
    await shot(page, '02-rush.png');
    await ctx.close();
  }
  // 03 — the café's signature karen camping at a table
  if (want('03')) {
    const { ctx, page } = await open(18, 3);
    await freePlay(page, 'cafe', 40);
    await freeze(page);
    await callKarens(page, ['squatter'], 1);
    let k = null;
    for (let tries = 0; tries < 12; tries++) {
      k = await runUntil(page, 'squatter', 240, ['camp']);
      if (k && k.z < 12) break;
      await page.evaluate(id => { const w = window.__game.conn.room.world; w.customers = w.customers.filter(c => c.id !== id); w.karenTimer = 0; }, k?.id);
    }
    await step(page, 40);
    const c = await page.evaluate(id => { const c = window.__game.conn.room.world.customers.find(c => c.id === id); return { x: c.x, z: c.z, yaw: c.yaw }; }, k.id);
    const a = c.yaw + 0.35, d = 2.9;
    const px = Math.min(23.3, Math.max(0.6, c.x + Math.sin(a) * d)), pz = Math.min(15.3, Math.max(0.6, c.z + Math.cos(a) * d));
    await lookAt(page, px, pz, c.x, c.z, 0.95);
    await tidy(page);
    await clearLine(page, px, pz, c.x, c.z, [k.id]);
    await step(page, 1);
    await shot(page, '03-signature.png', 1000);
    await ctx.close();
  }
  // 04 — the boss fight: 奧客之王 (chapter 6-3)
  if (want('04')) {
    const { ctx, page } = await open(29, 5, { extra: ['6-1', '6-2'] });
    await startShift(page, '6-3', 10);
    await freeze(page);
    const b = await runUntil(page, 'boss', 200, ['queue', 'atRegister']);
    await step(page, 160);
    const bp = await page.evaluate(id => { const c = window.__game.conn.room.world.customers.find(c => c.id === id); return { x: c.x, z: c.z }; }, b.id);
    await faceFrom(page, bp.x, bp.z, 1.3, { ty: 1.3 });
    await step(page, 2);
    await page.waitForTimeout(800);
    await press(page, 't-interact');
    for (let i = 0; i < 80; i++) {
      await step(page, 2);
      if (await page.evaluate(id => window.__game.conn.room.world.customers.find(c => c.id === id)?.phase >= 2, b.id)) break;
      await page.waitForTimeout(60);
    }
    await step(page, 100);
    const c = await page.evaluate(() => { const c = window.__game.conn.room.world.customers.find(c => c.kind === 'boss'); return c && { id: c.id, x: c.x, z: c.z, yaw: c.yaw }; });
    const a = c.yaw + 0.45, d = 3.1;
    const px = Math.min(23.3, Math.max(0.7, c.x + Math.sin(a) * d)), pz = Math.min(15.4, Math.max(0.7, c.z + Math.cos(a) * d));
    await lookAt(page, px, pz, c.x, c.z, 1.3);
    await clearLine(page, px, pz, c.x, c.z, [c.id]);
    await tidy(page);
    await step(page, 1);
    await shot(page, '04-boss.png');
    await ctx.close();
  }
  // 05 — career screen; 06 — the 21-store picker; 07 — title screen
  if (want('05') || want('06') || want('07')) {
    const { ctx, page } = await open(22, 4);
    if (want('07')) await shot(page, '07-title.png', 1500);
    await click(page, '#m-career');
    await page.waitForTimeout(800);
    if (want('05')) await shot(page, '05-career.png', 800);
    if (want('06')) { await click(page, '[data-tab="free"]'); await page.waitForSelector('.mapcard'); await shot(page, '06-maps.png', 800); }
    await ctx.close();
  }
}
await browser.close();
